import json
import os
import random
from datetime import datetime
import string

tasklocation = "./task.json"

class TaskManager:
    def __init__(self):
        self.tasklocation = tasklocation

    def generate_id(self):
        # Generate a random letter from the alphabet
        letter = random.choice(string.ascii_uppercase)
        # Generate a random number between 0 and 9
        number = random.randint(0, 9)
        # Combine the letter and number to create the ID
        return f"{letter}{number}"

    def create_task(self, description, deadline, priority, category, status):
        # Validar el campo 'status'
        while True:
            if status.upper()[0] not in ['P', 'I', 'C']:
                status = input("Invalid status. Please enter a valid status (P, I, or C): ")
            else:
                break

        # Validar el campo 'deadline'
        while True:
            try:
                deadline_datetime = datetime.strptime(deadline, '%Y-%m-%d')
                if deadline_datetime < datetime.now():
                    raise ValueError("Deadline must be a future date.")
                break
            except ValueError:
                deadline = input("Invalid deadline format. Deadline must be in the format 'YYYY-MM-DD': ")

        # Validar el campo 'priority'
        while True:
            if priority.upper() not in ['A', 'B', 'C']:
                priority = input("Invalid priority. Please enter a valid priority (A, B, or C): ")
            else:
                break

        # Generate task ID
        id_task = self.generate_id()

        # Create a dictionary representing the new task
        new_task = {
            "id": id_task,
            "description": description,
            "deadline": deadline,
            "priority": priority.upper(),
            "category": category,
            "status": status.upper()[0],
        }

        # Read existing tasks from the JSON file
        tasks = self.read_task()

        # Add the new task to the list
        tasks.append(new_task)

        # Write the updated list of tasks to the JSON file
        self.write_task(tasks)

    def read_task(self):
        if os.path.exists(self.tasklocation):
            with open(self.tasklocation, 'r') as data_file:
                try:
                    tasks = json.load(data_file)
                except json.JSONDecodeError:
                    tasks = []
        else:
            tasks = []

        return tasks

    def write_task(self, tasks):
        with open(self.tasklocation, 'w') as task_file:
            json.dump(tasks, task_file, indent=4)

    def update_task(self, task_id, **kwargs):
        tasks = self.read_task()
        for task in tasks:
            if task['id'] == task_id:
                # Validar el campo 'status'
                if 'status' in kwargs:
                    while True:
                        if kwargs['status'].upper()[0] not in ['P', 'I', 'C']:
                            kwargs['status'] = input("Invalid status. Please enter a valid status (P, I, or C): ")
                        else:
                            break

                # Validar el campo 'deadline'
                if 'deadline' in kwargs:
                    while True:
                        try:
                            deadline_datetime = datetime.strptime(kwargs['deadline'], '%Y-%m-%d')
                            if deadline_datetime < datetime.now():
                                raise ValueError("Deadline must be a future date.")
                            break
                        except ValueError:
                            kwargs['deadline'] = input("Invalid deadline format. Deadline must be in the format 'YYYY-MM-DD': ")

                # Validar el campo 'priority'
                if 'priority' in kwargs:
                    while True:
                        if kwargs['priority'].upper() not in ['A', 'B', 'C']:
                            kwargs['priority'] = input("Invalid priority. Please enter a valid priority (A, B, or C): ")
                        else:
                            break

                task.update(kwargs)
                break
        self.write_task(tasks)

    def list_id(self):
        tasks = self.read_task()
        for i, task in enumerate(tasks, start=1):
            print(f"{i}. ID: {task['id']} - Description: {task['description']}")

    def delete_task(self, task_id):
        tasks = self.read_task()
        tasks = [task for task in tasks if task['id'] != task_id]
        self.write_task(tasks)

    def filter_tasks(self, filter_type, filter_value):
        # Validar el campo 'filter_type'
        while True:
            if filter_type not in ['description', 'priority', 'category', 'status']:
                filter_type = input("Invalid filter type. Please enter a valid filter type (description, priority, category, or status): ")
            else:
                break

        tasks = self.read_task()

        # Ajustar el valor de filtro dependiendo del tipo de filtro
        if filter_type in ['priority', 'status']:
            filter_value = filter_value.upper()
        
        filtered_tasks = [task for task in tasks if task[filter_type] == filter_value]

        if not filtered_tasks:
            print(f"No tasks found with {filter_type} '{filter_value}'")
            return

        for i, task in enumerate(filtered_tasks, start=1):
            description = task['description']
            priority = task['priority']
            deadline = task['deadline']
            category = task['category']
            status = task['status']
            print(f"{'-'*10}#{i} {description} {'-'*10}\n  Category: {category} Priority: {priority}   Status: {status}   Deadline: {deadline}")

    def list_tasks(self):
        tasks = self.read_task()
        if not tasks:
            print("No tasks found.")
            return
        
        for i, task in enumerate(tasks, start=1):
            description = task['description']
            priority = task['priority']
            deadline = task['deadline']
            category = task['category']
            status = task['status']
            print(f"{'-'*10}#{i} {description} {'-'*10}\n  Category: {category} Priority: {priority}   Status: {status}   Deadline: {deadline}")

    def classify_task(self, classification_type):
        tasks = self.read_task()

        if classification_type == "priority":
            priorities = ['A', 'B', 'C']
            for priority in priorities:
                print(f"{'-'*10} PRIORITY {priority} {'-'*10}")
                for i, task in enumerate(tasks, start=1):
                    if task['priority'] == priority:
                        print(f"#{i} Task: {task['description']} Deadline: {task['deadline']} Category: {task['category']} Priority: {task['priority']} Status: {task['status']}")

        elif classification_type == "status":
            statuses = ['P', 'I', 'C']
            status_names = {'P': 'PENDING', 'I': 'IN PROGRESS', 'C': 'COMPLETED'}
            for status in statuses:
                print(f"{'-'*10} {status_names[status]} {'-'*10}")
                for i, task in enumerate(tasks, start=1):
                    if task['status'] == status:
                        print(f"#{i} Task: {task['description']} Deadline: {task['deadline']} Category: {task['category']} Priority: {task['priority']} Status: {task['status']}")
        
        elif classification_type == 'category':
            categories = set(task['category'] for task in tasks)
            for category in categories:
                print(f"{'-'*10}  {category} {'-'*10}")
                for i, task in enumerate(tasks, start=1):
                    if task['category'] == category:
                        print(f"#{i} Task: {task['description']} Deadline: {task['deadline']} Category: {task['category']} Priority: {task['priority']} Status: {task['status']}")